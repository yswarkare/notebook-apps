export type AuthJwtPayload = {
  sub: number;
};
