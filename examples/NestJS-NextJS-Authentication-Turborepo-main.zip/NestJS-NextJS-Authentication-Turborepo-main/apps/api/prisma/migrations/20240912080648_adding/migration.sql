-- AlterTable
ALTER TABLE "users" ADD COLUMN     "hashedRefreshToken" TEXT;
